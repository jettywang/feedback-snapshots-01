"""Ordinary wheel member used for the digest-mismatch control."""

MARKER = "tampered-control-value-0001"
